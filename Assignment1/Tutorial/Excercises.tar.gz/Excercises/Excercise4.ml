type time = Time of int * int * int 

TEST = Time(0,0,0) = Time(0,0,0)
